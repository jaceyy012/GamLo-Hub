## Packages
firebase | Authentication service
framer-motion | Cinematic animations and transitions
lucide-react | Beautiful icons
react-player | Video playback handling

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
